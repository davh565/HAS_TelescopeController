var searchData=
[
  ['ra_0',['RA',['../enums_8h.html#accc088009d44c521706aa98d6387ee21a37e8244fa8abfdd1341d85bdc58e6b31',1,'enums.h']]],
  ['reverse_1',['REVERSE',['../enums_8h.html#a99f26e6ee9fcd62f75203b5402df8098a906b7cc20b42994dda4da492767c1de9',1,'enums.h']]]
];
