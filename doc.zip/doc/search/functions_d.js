var searchData=
[
  ['rastr2double_0',['raStr2Double',['../namespacecomms.html#a7cef0b7a3731964deae703d629d02f9f',1,'comms']]],
  ['readstringuntilchar_1',['readStringUntilChar',['../namespacecomms.html#a2fdbf7ebdfea19c587de9a6f52523c67',1,'comms']]],
  ['reset_2',['reset',['../classio_1_1_encoder.html#a0617defbefc27b4d609abfbd3c30ba69',1,'io::Encoder']]],
  ['resetcount_3',['resetCount',['../class_pulse_generator.html#a4bb1b33bf49fd5571f9045303d466440',1,'PulseGenerator']]],
  ['resetpulsecount_4',['resetPulseCount',['../classio_1_1_stepper.html#a5936a5a954792fffd3ac45d9aaa4c37b',1,'io::Stepper']]],
  ['resetstepcount_5',['resetStepCount',['../class_pulse_generator_soft.html#af2132278de95326f6c8b5e1ecf291bf2',1,'PulseGeneratorSoft']]],
  ['run_6',['run',['../classio_1_1_stepper.html#a735e92dd186abc0044ade5777608340c',1,'io::Stepper::run(direction dir, uint32_t frequency)'],['../classio_1_1_stepper.html#a195a2b55f6ee8b43e33ff8a04671ed73',1,'io::Stepper::run(direction dir)']]],
  ['runangle_7',['runAngle',['../classio_1_1_stepper.html#a3024f2368d51f7cb79a15d62e4e593cc',1,'io::Stepper']]],
  ['runpulses_8',['runPulses',['../classio_1_1_stepper.html#a83337e3036b25fe52d22bea3d6074be1',1,'io::Stepper::runPulses(int32_t steps)'],['../classio_1_1_stepper.html#a65dd6d4870b2b39ba0a120cffc8617be',1,'io::Stepper::runPulses()']]],
  ['runtotarget_9',['runToTarget',['../classio_1_1_stepper.html#aa0cd44bd6b7eebf0745124cb36bd7236',1,'io::Stepper']]]
];
