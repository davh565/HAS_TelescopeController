var searchData=
[
  ['ai_5fpot_0',['AI_POT',['../config_8h.html#ae7645d3ab2dd3775af0ee17229ce4de3',1,'AI_POT():&#160;config.h'],['../tests_8ino.html#ae7645d3ab2dd3775af0ee17229ce4de3',1,'AI_POT():&#160;tests.ino']]],
  ['ai_5fpot_5fspeed_1',['AI_POT_SPEED',['../config_8h.html#a3041e6b2aa7b6a96cb5b34dfe75ac089',1,'AI_POT_SPEED():&#160;config.h'],['../config_8h.html#a3041e6b2aa7b6a96cb5b34dfe75ac089',1,'AI_POT_SPEED():&#160;config.h'],['../config_8h.html#a3041e6b2aa7b6a96cb5b34dfe75ac089',1,'AI_POT_SPEED():&#160;config.h']]]
];
