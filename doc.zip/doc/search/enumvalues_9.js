var searchData=
[
  ['oc1a_0',['oc1a',['../pulse_8h.html#a58a25d67459c54a9a90f8632cf75f019a2372a498d5531daeb3e2f5e83fb804ec',1,'pulse.h']]],
  ['oc3a_1',['oc3a',['../pulse_8h.html#a58a25d67459c54a9a90f8632cf75f019a3e9b6bb2e7b6ba4614fd5c89b0e2fc8a',1,'pulse.h']]],
  ['oc4a_2',['oc4a',['../pulse_8h.html#a58a25d67459c54a9a90f8632cf75f019a5be93a076b04b50af9fa186fa8cc9fc4',1,'pulse.h']]],
  ['oc5a_3',['oc5a',['../pulse_8h.html#a58a25d67459c54a9a90f8632cf75f019a27989cc19c042fb2b537cf8f08572073',1,'pulse.h']]]
];
