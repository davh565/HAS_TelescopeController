var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuvw",
  1: "efps",
  2: "cip",
  3: "cehipstu",
  4: "_abcdefghilmprstuw",
  5: "_abcdefghilmoprstv",
  6: "acdfp",
  7: "abcdfglmnorst",
  8: "adprst",
  9: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

