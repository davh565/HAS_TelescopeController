var searchData=
[
  ['set_5ftarget_5fdec_0',['SET_TARGET_DEC',['../enums_8h.html#a9e0992eae3950adccaf4847fbff4231dadd8c3d5fb2586becc9b12627543afe93',1,'enums.h']]],
  ['set_5ftarget_5fra_1',['SET_TARGET_RA',['../enums_8h.html#a9e0992eae3950adccaf4847fbff4231da8df420707f7c49b13d8df9c8cd24a1cc',1,'enums.h']]],
  ['sky_2',['SKY',['../pos_8h.html#a943f49763dd36e31fc7ea8604fcad789a7a44abebaba8f43f7e0bfbb68643772a',1,'pos.h']]],
  ['slew_5fto_5ftarget_3',['SLEW_TO_TARGET',['../enums_8h.html#a9e0992eae3950adccaf4847fbff4231da574d14d00b3673103e19fc657521dd98',1,'enums.h']]],
  ['stop_5fslew_4',['STOP_SLEW',['../enums_8h.html#a9e0992eae3950adccaf4847fbff4231da95e8f4b4657f3a41a8e3acb554841d97',1,'enums.h']]],
  ['sync_5fposition_5',['SYNC_POSITION',['../enums_8h.html#a9e0992eae3950adccaf4847fbff4231da185a714c9b426bd7b7e31c6c23971a85',1,'enums.h']]]
];
