var searchData=
[
  ['direction_0',['direction',['../enums_8h.html#a99f26e6ee9fcd62f75203b5402df8098',1,'enums.h']]]
];
