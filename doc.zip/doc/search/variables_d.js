var searchData=
[
  ['pina_0',['pinA',['../classio_1_1_encoder.html#aeaaeda071fa827e2b79055a4ae11a9b0',1,'io::Encoder']]],
  ['pinb_1',['pinB',['../classio_1_1_encoder.html#acfcde2d2d85a3a88306773f471174477',1,'io::Encoder']]],
  ['pindir_2',['pinDIR',['../classio_1_1_stepper.html#a2755428241a7cb0315eb5e24bb23943e',1,'io::Stepper']]],
  ['potval_3',['potVal',['../_h_a_s___telescope_controller_8ino.html#acf6c9f272d09c5969c38d0b7f0e693b5',1,'potVal():&#160;HAS_TelescopeController.ino'],['../tests_8ino.html#acf6c9f272d09c5969c38d0b7f0e693b5',1,'potVal():&#160;tests.ino']]],
  ['prescaler_4',['prescaler',['../pulse_8cpp.html#a2c4522c3a9586872b9755af525489016',1,'pulse.cpp']]],
  ['prevmicros_5',['prevMicros',['../class_pulse_generator_soft.html#afc747f411c2285e7ce39a99fb9e7ae70',1,'PulseGeneratorSoft']]],
  ['pulse_6',['Pulse',['../classio_1_1_stepper.html#a83cf5a2042562591f4660453d5df021a',1,'io::Stepper']]],
  ['pulsecount_7',['pulseCount',['../classio_1_1_encoder.html#abcb468418699a8d500c253242c7ac7cd',1,'io::Encoder::pulseCount()'],['../class_pulse_generator_soft.html#afedc8ec09303cb54923c0851c2eb1c32',1,'PulseGeneratorSoft::pulseCount()']]],
  ['pulsepin_8',['pulsePin',['../class_pulse_generator.html#a0ea295a03777f884eff5d5960f13d244',1,'PulseGenerator']]],
  ['pulsesperdeg_9',['pulsesPerDeg',['../structstepper_calibration.html#af3de2a340bf796ee2f69b9e70279581a',1,'stepperCalibration::pulsesPerDeg()'],['../classio_1_1_stepper.html#a6f3d5fbe75a98240bc70b645c31ad01e',1,'io::Stepper::pulsesPerDeg()']]],
  ['pulsestate1_10',['pulseState1',['../pulse_8cpp.html#a2c183e1f708b8339ae3a4e6fb2da9f15',1,'pulse.cpp']]],
  ['pulsestate3_11',['pulseState3',['../pulse_8cpp.html#adc47a76282b493f9e22617c731a07e76',1,'pulse.cpp']]],
  ['pulsestate4_12',['pulseState4',['../pulse_8cpp.html#a7a5e220c3a070737ff0ca7a439a330cc',1,'pulse.cpp']]],
  ['pulsestate5_13',['pulseState5',['../pulse_8cpp.html#a8ac101bbc4438cf570434a5c9351c781',1,'pulse.cpp']]]
];
