var searchData=
[
  ['automanualmode_0',['autoManualMode',['../ctrl_8h.html#a8b0e23f75be8be98da04d14c2958347e',1,'ctrl.h']]],
  ['axis_1',['axis',['../enums_8h.html#accc088009d44c521706aa98d6387ee21',1,'enums.h']]]
];
