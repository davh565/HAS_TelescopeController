var searchData=
[
  ['scl_5flcd_0',['SCL_LCD',['../config_8h.html#a42923dfdb8a2c70052698c74eed24234',1,'config.h']]],
  ['sda_5flcd_1',['SDA_LCD',['../config_8h.html#adb1c94f9ba1348bc11a6df857533caa7',1,'config.h']]]
];
