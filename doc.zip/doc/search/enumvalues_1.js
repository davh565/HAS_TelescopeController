var searchData=
[
  ['base_0',['BASE',['../pos_8h.html#a943f49763dd36e31fc7ea8604fcad789aa7d623548e49a1514076f5bee3b314a4',1,'pos.h']]],
  ['both_1',['BOTH',['../ctrl_8h.html#a8b0e23f75be8be98da04d14c2958347ea627abe5a430420baf29ebe1940a7f2fb',1,'ctrl.h']]]
];
