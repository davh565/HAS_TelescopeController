var searchData=
[
  ['target_0',['TARGET',['../pulse_8h.html#a61ad309e7642d2c4c809c31a87cf4bc9a09aa9e75617e9d8719738ca163c09137',1,'pulse.h']]]
];
