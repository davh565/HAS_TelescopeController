var searchData=
[
  ['g_5fdeclimhi_0',['g_decLimHi',['../io_8cpp.html#a2a07b95e30b24a9bcd724dba20c3ce14',1,'io.cpp']]],
  ['g_5fdeclimlo_1',['g_decLimLo',['../io_8cpp.html#abce0458054ee780fa0b1e6c0db3b02ab',1,'io.cpp']]]
];
