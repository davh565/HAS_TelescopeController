var searchData=
[
  ['txd2_5fr_5fpi_0',['TXD2_R_PI',['../config_8h.html#aa217e2f452f11b7aafb930af90041ad2',1,'config.h']]],
  ['txd3_5fdebug_1',['TXD3_DEBUG',['../config_8h.html#a04c1d53789ce65d0b96a35e1506c2bc5',1,'config.h']]]
];
